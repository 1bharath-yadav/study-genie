export const SYSTEM_PROMPTS = `You are a helpful assistant.`;
